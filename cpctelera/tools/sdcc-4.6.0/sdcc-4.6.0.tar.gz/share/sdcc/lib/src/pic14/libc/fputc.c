/*-------------------------------------------------------------------------
   fputc.c - write a character to a stream

   Copyright (C) 2005, Vangelis Rokas <vrokas AT otenet.gr>

   Modifications for PIC14 by
   Copyright (C) 2019 Gonzalo Pérez de Olaguer Córdoba <salo@gpoc.es>

   This library is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 2, or (at your option) any
   later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License 
   along with this library; see the file COPYING. If not, write to the
   Free Software Foundation, 51 Franklin Street, Fifth Floor, Boston,
   MA 02110-1301, USA.

   As a special exception, if you link this library with other files,
   some of which are compiled with SDCC, to produce an executable,
   this library does not by itself cause the resulting executable to
   be covered by the GNU General Public License. This exception does
   not however invalidate any other reasons why the executable file
   might be covered by the GNU General Public License.
-------------------------------------------------------------------------*/

#include <stdio.h>

int fputc (char c, FILE *stream)
{
  char *p;
  unsigned char tag;

  /* if stream is NULL use putchar */
  if (!stream)
  	return putchar (c);

  p = *stream;
  tag = ((char*)&p)[2];

  /* this is a __code pointer */
  if (tag)
#if !(defined(__SDCC_pic14) && !defined(__SDCC_PIC14_HAS_PCALL))
  	return ((_stream_out_handler*)p) (c, stream);
#else
	return EOF;
#endif

  /* this is a __data pointer */
  *p = c;
  *(char **)stream = p+1;

  return (unsigned char)c;
}
